<template>
  
  <div>
    <header>
      <img src="./assets/pokemon.png" alt="">
    </header>
    <main>
      <PokeList>
      </PokeList>
    </main>
  </div>
</template>

<script>
import PokeList from './components/PokeList.vue'

export default {
  name: 'App',
  components: {
    PokeList
  }
}
</script>

<style>
header {
  display: flex;
  justify-content: space-around;
  padding-bottom: 100px;
  padding-top: 100px;
}

header img{
  max-width: 100%; /* Assurer que l'image ne dépasse pas la largeur du conteneur */
  height: auto; 
}
body {
    background-color: #385561; 
    background-image: linear-gradient( #385561, #1b292f); /* Dégradé de haut en bas */
}


</style>
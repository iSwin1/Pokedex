<template>
  <div class="container">
    <PokeCard v-for="pokemon of pokemons" :key="pokemon.name" :pokemon="pokemon">
    </PokeCard>
  </div>
</template>

<script>
import PokeCard from './PokeCard.vue'
import json_pokemons from '@/assets/pokemon.json'

export default {
  name: 'PokeList',
  components: {
    PokeCard
  },
  data() {
    return {
      pokemons: json_pokemons,
      selectedPokemon: null
    }
  },
  methods: {
    mamethode() {
      console.log("On m'a clické dessus !!!")
    }
  }
}
</script>

<style scoped>
.container {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}

</style>

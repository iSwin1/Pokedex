<template>
    <div class="card" :class="pokemon.type1" @mouseenter="afficherInfo = true" @mouseleave="afficherInfo = false">
      <div class="overlay"></div>
      <img :src="imagePath"/>
      <div class="pokemon-info">
        <div v-if="afficherInfo"> 
        <div class="info-row">
          ❤️ HP : <p>{{ pokemon.hp }}</p>
        </div>
        <div class="info-row">
          ⚔️ Attack : <p>{{ pokemon.attack }}</p>
        </div>
        <div class="info-row">
          🛡️ Defense : <p>{{ pokemon.defense }}</p>
        </div>
        <div class="info-row">
          💨 Speed : <p>{{ pokemon.speed }}</p>
        </div>
        <div class="info-row">
          🏋️ Weight KG : <p>{{ pokemon.weight_kg }}</p>
        </div>
      </div>
        <div v-else>
            <h1>{{pokemon.name}}</h1>
        <p>{{ pokemon.type1 }}</p>
        
        </div>
      </div>
    </div>
  </template>
  
<script>
export default {
    data () {
        return {
            afficherInfo: false
        }
    },
    props: {
        pokemon: {
            type: Object,
            required: true
        }
    },
    computed: {
        imagePath() {
            return (`/images2/${this.pokemon.pokedex_number}.png`);
    }
}}

</script>

<style>

@font-face 

{
    font-family: 'PokemonFont';
    src: url('@/fonts/pokemonfont.ttf') format('truetype');
}
.card {
  position: relative;
  margin: 1em;
  padding: 1em;
  border-radius: 15px;
  width: 300px;
  height: 450px;
  box-shadow: 0 8px 18px black;
  border: 5px solid white;
  font-family: 'PokemonFont', sans-serif;
  overflow: hidden;
}

.overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: rgba(0, 0, 0, 0); /* Transparent par défaut */
  transition: background-color 0.3s ease-in-out; /* Transition pour l'effet de survol */
  z-index: 1;
}

.card:hover .overlay {
  background-color: rgba(0, 0, 0, 0.5); /* Assombrit l'overlay au survol */
}


h1 {
  font-size: 50px;
  text-shadow: 0px 0px 12px #ffffff;
  margin-bottom: 0;
}


.card img {
    width: 100%; /* Assurez-vous que l'image occupe toute la largeur de la carte */
    border-bottom-left-radius: 10px;
    border-bottom-right-radius: 10px;
}

.pokemon-info {
    text-align: center;
    color: white;
    transform: translateY(-50%);
    position: relative;
    z-index: 2;
}

.card img {
  width: 100%;
  border-bottom-left-radius: 10px;
  border-bottom-right-radius: 10px;
}

.info-row {
  margin-bottom: 5px; /* Espacement entre chaque ligne de statistique */
  display: flex;
  align-items: center;
  justify-content: center;
  
}

/* Ajoutez des classes de couleur en fonction du type de Pokémon */
.grass { background-color: #78C850;}
.fire { background-color: #F08030; }
.water { background-color: #6890F0; }
.bug { background-color: #A8B820; }
.poison { background-color: #A040A0; }
.flying { background-color: #A890F0; }
.normal { background-color: #A8A878; }
.electric { background-color: #F8D030; }
.ground { background-color: #E0C068; }
.fairy { background-color: #EE99AC; }
.fighting { background-color: #C03028; }
.psychic { background-color: #F85888; }
.rock { background-color: #B8A038; }
.ice { background-color: #98D8D8; }
.ghost { background-color: #705898; }
.dragon { background-color: #7038F8; }
.steel { background-color: #B8B8D0; }
.dark { background-color: #705848; }

.grass h1{color: #78C850}
.fire h1{color: #F08030}
.water h1{color: #6890F0}
.bug h1{color: #A8B820}
.poison h1{color: #A040A0}
.flying h1{color: #A890F0}
.normal h1{color: #A8A878}
.electric h1{color: #F8D030}
.ground h1{color: #E0C068}
.fairy h1{color: #EE99AC}
.fighting h1{color: #C03028}
.psychic h1{color: #F85888}
.rock h1{color: #B8A038}
.ice h1{color: #98D8D8}
.ghost h1{color: #705898}
.dragon h1{color: #7038F8}
.steel h1{color: #B8B8D0}
.dark h1{color: #705848}

</style>
